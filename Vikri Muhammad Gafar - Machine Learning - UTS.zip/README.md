# Machine-Learning-UTS-November-2022

Universitas Paramadina

Nama : Vikri Muhammad Gafar
NIM : 122103019

untuk memenuhi UTS Pembelajaran Mesin